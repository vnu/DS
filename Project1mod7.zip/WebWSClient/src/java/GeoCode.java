
import java.rmi.RemoteException;


public class GeoCode {

	/**
	 * @param args
	 * @throws ExceptionException
	 * @throws RemoteException
	 */
	public static void main(String[] args) throws RemoteException, Exception {

web.server.WeatherWebService service = new web.server.WeatherWebService();
	web.server.WeatherWeb port = service.getWeatherWebPort();
	 // TODO initialize WS operation arguments here
	java.lang.String source = "13454";
	java.lang.String destination = "88232";
	java.lang.String date = "2011-03-17";
	// TODO process result here
	java.util.List<web.server.WeatherInfo> wInfo = port.geoMapService(source, destination, date);
	for(int i=0;i<wInfo.size();i++)
{
System.out.println(wInfo.get(i).getLatitude());
}






	}

}
