/**
 * 
 */
package dbConnection;

import java.sql.Connection;





/**
 * @author Vinu Charanya
 * 
 */
public interface IDbConnect {

	

	public abstract Connection getConnection();

	public abstract void close();

}
