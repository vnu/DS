package compute;

import java.util.ArrayList;



public interface IWeatherInfo<T> {
	T retrieve(ArrayList<String> zipc) ;
}
