/**
 * @author Vinu Charanya
 *
 */
 
package compute;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;


public interface IWeather extends Remote {

	//<T> T retrievedata(IWeatherInfo<T> t) throws RemoteException;
        ArrayList<WeatherInfo> RetrieveData(ArrayList<String> c_zip) throws RemoteException;
	
}

