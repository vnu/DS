/**
 * @author Vinu Charanya
 *
 */
package client;

import java.io.Serializable;
import compute.WeatherInfo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class DispWeather implements Serializable {

    /**
     *
     */
    WeatherInfo wInfos;
    private static final long serialVersionUID = 1L;
    ArrayList<String> zipcodes = new ArrayList<String>();

    public DispWeather() {
    }

    public ArrayList<String> GetZipcodes() {
        try {

            InputStreamReader isr = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(isr);
            String userzip = null;
            System.out.print("\nEnter the 5 digit zip or 'Exit'\t:\t");
            userzip = br.readLine();
            while (!(userzip.equalsIgnoreCase("exit"))) {
                zipcodes.add(userzip);
                System.out.print("\nEnter the 5 digit zip or 'Exit'\t:\t");
                userzip = br.readLine();
                System.out.println("zip..." + userzip);
            }

        } catch (IOException ex) {
            ex.getMessage();
        }

        return zipcodes;
    }

    public void weatherdisplay(ArrayList<WeatherInfo> cwInfo) {
        for (WeatherInfo wInfo : cwInfo) {
            System.out.println("zipcode : " + wInfo.getZipcode());
            System.out.println("City : " + wInfo.getLoc_city());
            System.out.println("Region : " + wInfo.getLoc_region());
        }

    }
}
