/**
* @author Vinu Charanya
 *
 */
package weatherDB;

import java.io.Serializable;


/**
 * 
 * Class with variables to store data from RSS feed retrieved by WeatherServer.
 * 
 */
public class WeatherInfo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String title;
    private String zipcode;
    private String loc_city;
    private String loc_region;
    private String loc_country;
    private String units_temperature;
    private String units_distance;
    private String units_pressure;
    private String units_speed;
    private float wind_chill;
    private float wind_direction;
    private float wind_speed;
    private float atm_humidity;
    private float atm_visibility;
    private float atm_pressure;
    private float atm_rising;
    private String astro_sunrise;
    private String astro_sunset;
    private String cond_text;
    private float cond_code;
    private float cond_temp;
    private String cond_date;
    private String date;
    private String ddt;
    private String day;
    private String wtime;
    private String zone;
    private String forecast_day;
    private String forecast_date;
    private float forecast_low;
    private float forecast_high;
    private String forecast_text;
    private float forecast_code;
    private String latitude;
    private String longitude;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getLoc_city() {
        return loc_city;
    }

    public void setLoc_city(String loc_city) {
        this.loc_city = loc_city;
    }

    public String getLoc_region() {
        return loc_region;
    }

    public void setLoc_region(String loc_region) {
        this.loc_region = loc_region;
    }

    public String getLoc_country() {
        return loc_country;
    }

    public void setLoc_country(String loc_country) {
        this.loc_country = loc_country;
    }

    public String getUnits_temperature() {
        return units_temperature;
    }

    public void setUnits_temperature(String units_temperature) {
        this.units_temperature = units_temperature;
    }

    public String getUnits_distance() {
        return units_distance;
    }

    public void setUnits_distance(String units_distance) {
        this.units_distance = units_distance;
    }

    public String getUnits_pressure() {
        return units_pressure;
    }

    public void setUnits_pressure(String units_pressure) {
        this.units_pressure = units_pressure;
    }

    public String getUnits_speed() {
        return units_speed;
    }

    public void setUnits_speed(String units_speed) {
        this.units_speed = units_speed;
    }

    public float getWind_chill() {
        return wind_chill;
    }

    public void setWind_chill(float wind_chill) {
        this.wind_chill = wind_chill;
    }

    public float getWind_direction() {
        return wind_direction;
    }

    public void setWind_direction(float wind_direction) {
        this.wind_direction = wind_direction;
    }

    public float getWind_speed() {
        return wind_speed;
    }

    public void setWind_speed(float wind_speed) {
        this.wind_speed = wind_speed;
    }

    public float getAtm_humidity() {
        return atm_humidity;
    }

    public void setAtm_humidity(float atm_humidity) {
        this.atm_humidity = atm_humidity;
    }

    public float getAtm_visibility() {
        return atm_visibility;
    }

    public void setAtm_visibility(float atm_visibility) {
        this.atm_visibility = atm_visibility;
    }

    public float getAtm_pressure() {
        return atm_pressure;
    }

    public void setAtm_pressure(float atm_pressure) {
        this.atm_pressure = atm_pressure;
    }

    public float getAtm_rising() {
        return atm_rising;
    }

    public void setAtm_rising(float atm_rising) {
        this.atm_rising = atm_rising;
    }

    public String getAstro_sunrise() {
        return astro_sunrise;
    }

    public void setAstro_sunrise(String astro_sunrise) {
        this.astro_sunrise = astro_sunrise;
    }

    public String getAstro_sunset() {
        return astro_sunset;
    }

    public void setAstro_sunset(String astro_sunset) {
        this.astro_sunset = astro_sunset;
    }

    public String getCond_text() {
        return cond_text;
    }

    public void setCond_text(String cond_text) {
        this.cond_text = cond_text;
    }

    public float getCond_code() {
        return cond_code;
    }

    public void setCond_code(float cond_code) {
        this.cond_code = cond_code;
    }

    public float getCond_temp() {
        return cond_temp;
    }

    public void setCond_temp(float cond_temp) {
        this.cond_temp = cond_temp;
    }

    public String getCond_date() {
        return cond_date;
    }

    public void setCond_date(String cond_date) {
        this.cond_date = cond_date;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getWtime() {
        return wtime;
    }

    public void setWtime(String wtime) {
        this.wtime = wtime;
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getForecast_day() {
        return forecast_day;
    }

    public void setForecast_day(String forecast_day) {
        this.forecast_day = forecast_day;
    }

    public String getForecast_date() {
        return forecast_date;
    }

    public void setForecast_date(String forecast_date) {
        this.forecast_date = forecast_date;
    }

    public float getForecast_low() {
        return forecast_low;
    }

    public void setForecast_low(float forecast_low) {
        this.forecast_low = forecast_low;
    }

    public float getForecast_high() {
        return forecast_high;
    }

    public void setForecast_high(float forecast_high) {
        this.forecast_high = forecast_high;
    }

    public String getForecast_text() {
        return forecast_text;
    }

    public void setForecast_text(String forecast_text) {
        this.forecast_text = forecast_text;
    }

    public float getForecast_code() {
        return forecast_code;
    }

    public void setForecast_code(float forecast_code) {
        this.forecast_code = forecast_code;
    }

    public String getDdt() {
        return ddt;
    }

    public void setDdt(String ddt) {
        this.ddt = ddt;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
}
