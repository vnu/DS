/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package web.server;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import weatherDB.WeatherInfo;

import dbConnection.DbConnection;
import dbConnection.IDbConnect;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

/**
 *
 * @author Vnu
 */
@WebService()
public class weatherWeb {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "fConverter")
    public Float fahrenheitConverter(@WebParam(name = "fahrenheit") float fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "celciusConverter")
    public Float celsiusConverter(@WebParam(name = "celcius") float celsius) {
        return (celsius * 9 / 5) + 32;

    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "RetrieveData")
    public WeatherInfo RetrieveData(@WebParam(name = "czip") String czip) {
        WeatherInfo cwInfo = new WeatherInfo();
        IDbConnect dbcon = new DbConnection();
        System.out.println("Inside cientdata");
        Connection con = dbcon.getConnection();
        try {
            Statement stmt = con.createStatement();
            //for (String czip : c_zip) {
            System.out.println("zipcode ..." + czip);
            //cwInfo.add(new WeatherInfo());
            String retinfo = "SELECT * FROM WEATHERTABLE WHERE ZIPCODE = '" + czip + "'";
            //String ret = String.format(retinfo,czip);
            ResultSet rs = stmt.executeQuery(retinfo);
            while (rs.next()) {

                cwInfo.setZipcode(rs.getString("ZIPCODE"));
                cwInfo.setLoc_city(rs.getString("LOC_CITY"));
                cwInfo.setLoc_region(rs.getString("LOC_REGION"));
                cwInfo.setLoc_country(rs.getString("LOC_COUNTRY"));

                cwInfo.setUnits_temperature(rs.getString("UNITS_TEMP"));
                cwInfo.setUnits_distance(rs.getString("UNITS_DIST"));
                cwInfo.setUnits_pressure(rs.getString("UNITS_PRESSURE"));
                cwInfo.setUnits_speed(rs.getString("UNITS_SPEED"));

                cwInfo.setWind_chill(rs.getFloat("WIND_CHILL"));
                cwInfo.setWind_speed(rs.getFloat("WIND_SPEED"));
                cwInfo.setWind_direction(rs.getFloat("WIND_DIR"));

                cwInfo.setAtm_humidity(rs.getFloat("ATM_HUMIDITY"));
                cwInfo.setAtm_visibility(rs.getFloat("ATM_VISIBILITY"));
                cwInfo.setAtm_pressure(rs.getFloat("ATM_PRESSURE"));
                cwInfo.setAtm_rising(rs.getFloat("ATM_RISING"));

                cwInfo.setAstro_sunrise((rs.getTime("ATM_SUNRISE")).toString());
                cwInfo.setAstro_sunset((rs.getTime("ATM_SUNSET")).toString());
                cwInfo.setCond_code(rs.getFloat("COND_CODE"));
                cwInfo.setCond_text(rs.getString("COND_TEXT"));
                cwInfo.setCond_temp(rs.getFloat("COND_TEMP"));
                cwInfo.setCond_date(rs.getString("COND_DATE"));

                cwInfo.setDdt(rs.getString("DDT"));
                cwInfo.setDay(rs.getString("DAY"));
                cwInfo.setWtime(rs.getTime("WTIME").toString());
                cwInfo.setZone(rs.getString("ZONE"));

                cwInfo.setForecast_day(rs.getString("FORECAST_DAY"));
                cwInfo.setForecast_date((rs.getDate("FORECAST_DATE")).toString());
                cwInfo.setForecast_low(rs.getFloat("FORECAST_LOW"));
                cwInfo.setForecast_high(rs.getFloat("FORECAST_HIGH"));
                cwInfo.setForecast_text(rs.getString("FORECAST_TEXT"));
                cwInfo.setForecast_code(rs.getFloat("FORECAST_CODE"));


            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
        return cwInfo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "cityweather")
    public WeatherInfo cityweather(@WebParam(name = "city") String city, @WebParam(name = "date") String date) {
        WeatherInfo cwInfo = new WeatherInfo();
        IDbConnect dbcon = new DbConnection();
        System.out.println("Inside cientdata");
        Connection con = dbcon.getConnection();
        try {
            Statement stmt = con.createStatement();

            String retinfo = "SELECT * FROM WEATHERTABLE WHERE LOC_CITY = '" + city + "' AND FORECAST_DATE = '" + date + "'";
            System.out.println("date = " + date);
            System.out.println("cate = " + city);
            ResultSet rs = stmt.executeQuery(retinfo);
            while (rs.next()) {

                cwInfo.setZipcode(rs.getString("ZIPCODE"));
                cwInfo.setLoc_city(rs.getString("LOC_CITY"));
                cwInfo.setLoc_region(rs.getString("LOC_REGION"));
                cwInfo.setLoc_country(rs.getString("LOC_COUNTRY"));

                cwInfo.setUnits_temperature(rs.getString("UNITS_TEMP"));
                cwInfo.setUnits_distance(rs.getString("UNITS_DIST"));
                cwInfo.setUnits_pressure(rs.getString("UNITS_PRESSURE"));
                cwInfo.setUnits_speed(rs.getString("UNITS_SPEED"));

                cwInfo.setWind_chill(rs.getFloat("WIND_CHILL"));
                cwInfo.setWind_speed(rs.getFloat("WIND_SPEED"));
                cwInfo.setWind_direction(rs.getFloat("WIND_DIR"));

                cwInfo.setAtm_humidity(rs.getFloat("ATM_HUMIDITY"));
                cwInfo.setAtm_visibility(rs.getFloat("ATM_VISIBILITY"));
                cwInfo.setAtm_pressure(rs.getFloat("ATM_PRESSURE"));
                cwInfo.setAtm_rising(rs.getFloat("ATM_RISING"));


                cwInfo.setAstro_sunrise((rs.getTime("ATM_SUNRISE")).toString());
                cwInfo.setAstro_sunset((rs.getTime("ATM_SUNSET")).toString());
                cwInfo.setCond_code(rs.getFloat("COND_CODE"));
                cwInfo.setCond_text(rs.getString("COND_TEXT"));
                cwInfo.setCond_temp(rs.getFloat("COND_TEMP"));
                cwInfo.setCond_date(rs.getString("COND_DATE"));

                cwInfo.setDdt(rs.getString("DDT"));
                cwInfo.setDay(rs.getString("DAY"));
                cwInfo.setWtime(rs.getTime("WTIME").toString());
                cwInfo.setZone(rs.getString("ZONE"));

                cwInfo.setForecast_day(rs.getString("FORECAST_DAY"));
                cwInfo.setForecast_date((rs.getDate("FORECAST_DATE")).toString());
                cwInfo.setForecast_low(rs.getFloat("FORECAST_LOW"));
                cwInfo.setForecast_high(rs.getFloat("FORECAST_HIGH"));
                cwInfo.setForecast_text(rs.getString("FORECAST_TEXT"));
                cwInfo.setForecast_code(rs.getFloat("FORECAST_CODE"));


            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
        return cwInfo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CityAverage")
    public float CityAverage(@WebParam(name = "City") String City, @WebParam(name = "FirstDate") String FirstDate, @WebParam(name = "SecondDate") String SecondDate) {
        float avg = 0.0f;
        System.out.println("Date" + FirstDate);
        System.out.println("Date" + SecondDate);
        System.out.println("City" + City);
        //WeatherInfo cwInfo = new WeatherInfo();
        IDbConnect dbcon = new DbConnection();
        System.out.println("Inside clientdata");
        Connection con = dbcon.getConnection();

        try {
            Statement stmt = con.createStatement();

            String retinfo = "SELECT AVG(COND_TEMP) AS AVGTEMP FROM WEATHERTABLE WHERE LOC_CITY = '" + City + "' AND FORECAST_DATE BETWEEN '" + FirstDate + "' AND '" + SecondDate + "'";
            ResultSet rs = stmt.executeQuery(retinfo);
            if (rs.next()) {
                avg = rs.getFloat(1);
            }
            System.out.println("Average : " + avg);

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
        System.out.println("average" + avg);
        return avg;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "geoMapService")
    public WeatherInfo[] geoMapService(@WebParam(name = "source") String source, @WebParam(name = "destination") String destination, @WebParam(name = "date") String date) {
        ArrayList<String> arrLat = new ArrayList<String>();
        ArrayList<String> arrLng = new ArrayList<String>();
        ArrayList<String> routeZip = new ArrayList<String>();
        System.out.println("date : "+date);
        WeatherInfo[] wmap = null;
        int mval = 0;
        String lat, lng;
        String webaddr = "http://maps.googleapis.com/maps/api/directions/xml?origin=" + source + "&destination=" + destination + "&sensor=false";

        URL mapURL = null;
        try {
            mapURL = new URL(webaddr);
        } catch (MalformedURLException ex) {
             ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
        SAXReader mapxmlReader = new SAXReader();
        Document mapfeed = null;
        try {
            mapfeed = (Document) mapxmlReader.read(mapURL);
        } catch (DocumentException ex) {
             ex.printStackTrace();
            System.out.println(ex.getMessage());
        }

        while (true) {
            if (mval == 0) {
                lat = mapfeed.valueOf("/DirectionsResponse/route/leg/step/start_location[1]/lat");
                lng = mapfeed.valueOf("/DirectionsResponse/route/leg/step/start_location[1]/lng");
                if (lat.length() != 0) {
                    arrLat.add(lat);
                    arrLng.add(lng);
                    System.out.println("Start Location : " + arrLat.get(0));
                    System.out.println("Start Location : " + arrLng.get(0));
                    mval++;
                } else {
                    break;
                }
            } else {
                lat = mapfeed.valueOf("/DirectionsResponse/route/leg/step[" + mval + "]/end_location/lat");
                lng = mapfeed.valueOf("/DirectionsResponse/route/leg/step[" + mval + "]/end_location/lng");
                if (lat.length() != 0) {
                    arrLat.add(lat);
                    arrLng.add(lng);
                    System.out.println("End Location : " + mval + " : " + arrLat.get(mval));
                    System.out.println("End Location : " + mval + " : " + arrLng.get(mval));
                    mval++;
                } else {
                    break;
                }

            }

        }

        for (int i = 0; i <mval; i++) {
            try {
                String zipaddr = "http://maps.googleapis.com/maps/api/geocode/xml?latlng=" + arrLat.get(i) + "," + arrLng.get(i) + "&sensor=false";
                String Title;
                URL zipURL = null;
                zipURL = new URL(zipaddr);
                SAXReader zipxmlReader = new SAXReader();
                Document zipfeed = null;
                
                try {
                    zipfeed = zipxmlReader.read(zipURL);
                } catch (DocumentException ex) { ex.printStackTrace();
                    System.out.println(ex.getMessage());
                }
                String wzip = zipfeed.valueOf("/GeocodeResponse/result/address_component[type/text()='postal_code']/long_name");
                System.out.println("zip:"+i+":" + wzip);
                routeZip.add(wzip);
                try {
                    Thread.sleep(100);
                    } catch (InterruptedException ex) {
                    Logger.getLogger(weatherWeb.class.getName()).log(Level.SEVERE, null, ex);
                }                    
            }
            //WeatherInfo [] wmap = ClientData(routeZip,arrLat,arrLng,date);
            catch (MalformedURLException ex) {
                ex.printStackTrace();
                Logger.getLogger(weatherWeb.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        int i=0;
        wmap=new WeatherInfo[routeZip.size()];
     for(String wzip:routeZip)
     {
        String addr = "http://weather.yahooapis.com/forecastrss?p=" + wzip;
                    URL myURL = null;
                    try {
                    myURL = new URL(addr);
                    } catch (MalformedURLException ex) {
                    System.out.println(ex.getMessage());
                    }
                    SAXReader xmlReader = new SAXReader();
                    Document feed = null;
                    try {
                    feed = (Document) xmlReader.read(myURL);
                    } catch (DocumentException ex) {
                    System.out.println(ex.getMessage());
                    }
                    String Title = feed.valueOf("/rss/channel/title/.");
                    //wInfo.get(zval).setTitle(Title);
                    if (Title.equals("Yahoo! Weather - Error")||Title.equals("City not found")) {
                    System.out.println("Weather not found for the zip code : " + wzip);
                    continue;
                    } else {
                    wmap[i] = new WeatherInfo();
                    wmap[i].setTitle(Title);
                    wmap[i].setZipcode(wzip);
                    wmap[i].setLatitude(arrLat.get(i));
                    wmap[i].setLongitude(arrLng.get(i));
                    System.out.println("I came here :");
                    //System.out.println("Location : ");
                    wmap[i].setLoc_city(feed.valueOf("/rss/channel/yweather:location/@city"));
                    System.out.println("I came here :"+wmap[i].getLoc_city());
                    wmap[i].setLoc_city(wmap[i].getLoc_city().replaceAll("'", " "));
                    wmap[i].setLoc_region(feed.valueOf("/rss/channel/yweather:location/@region"));
                    wmap[i].setLoc_country(feed.valueOf("/rss/channel/yweather:location/@country"));
                                        System.out.println("I came here :"+wmap[i].getLoc_country());
                    //System.out.println("Units : ");
                    wmap[i].setUnits_temperature(feed.valueOf("/rss/channel/yweather:units/@temperature"));
                    wmap[i].setUnits_distance(feed.valueOf("/rss/channel/yweather:units/@distance"));
                    wmap[i].setUnits_pressure(feed.valueOf("/rss/channel/yweather:units/@pressure"));
                    wmap[i].setUnits_speed(feed.valueOf("/rss/channel/yweather:units/@speed"));
                    //System.out.println("Wind : ");
                    String win_chill = feed.valueOf("/rss/channel/yweather:wind/@chill");
                    if (win_chill != "") {
                    wmap[i].setWind_chill((Float.parseFloat(win_chill)));
                    } else {
                    wmap[i].setWind_chill(0);
                    }
                    String win_dir = feed.valueOf("/rss/channel/yweather:wind/@direction");
                    if (win_dir != "") {
                    wmap[i].setWind_direction(Float.parseFloat(win_dir));
                    } else {
                    wmap[i].setWind_direction(0);
                    }
                    String win_speed = feed.valueOf("/rss/channel/yweather:wind/@speed");
                    if (win_speed != "") {
                    wmap[i].setWind_speed(Float.parseFloat(win_speed));
                    } else {
                    wmap[i].setWind_speed(0);
                    }
                    //System.out.println("Atmosphere : ");
                    String atm_hum = feed.valueOf("/rss/channel/yweather:atmosphere/@humidity");
                    if (atm_hum != "") {
                    wmap[i].setAtm_humidity(Float.parseFloat((atm_hum)));
                    } else {
                    wmap[i].setAtm_humidity(0);
                    }
                    String atm_vis = feed.valueOf("/rss/channel/yweather:atmosphere/@visibility");
                    if (atm_vis != "") {
                    wmap[i].setAtm_visibility(Float.parseFloat(atm_vis));
                    } else {
                    wmap[i].setAtm_visibility(0);
                    }
                    String atm_pr = feed.valueOf("/rss/channel/yweather:atmosphere/@pressure");
                    if (atm_pr != "") {
                    wmap[i].setAtm_pressure(Float.parseFloat(atm_pr));
                    } else {
                    wmap[i].setAtm_pressure(0);
                    }
                    String atm_ris = feed.valueOf("/rss/channel/yweather:atmosphere/@rising");
                    if (atm_ris != "") {
                    wmap[i].setAtm_rising(Float.parseFloat(atm_ris));
                    } else {
                    wmap[i].setAtm_rising(0);
                    }
                    //System.out.println("Astronomy : ");
                    wmap[i].setAstro_sunrise(feed.valueOf("/rss/channel/yweather:astronomy/@sunrise"));
                    wmap[i].setAstro_sunset(feed.valueOf("/rss/channel/yweather:astronomy/@sunset"));
                    //System.out.println("Condition : ");
                    wmap[i].setCond_text(feed.valueOf("/rss/channel/item/yweather:condition/@text"));
                    wmap[i].setCond_code(Float.parseFloat(feed.valueOf("/rss/channel/item/yweather:condition/@code")));
                    wmap[i].setCond_temp(Float.parseFloat(feed.valueOf("/rss/channel/item/yweather:condition/@temp")));
                    String wddt = feed.valueOf("/rss/channel/item/yweather:condition/@date");
                    wmap[i].setCond_date(wddt);
                    String delim = "[ ,]+";
                    String[] tokens = wddt.split(delim);
                    String Day = tokens[0];
                    wmap[i].setDay(Day);
                    String Date = tokens[1] + " " + tokens[2] + " " + tokens[3];
                    wmap[i].setDate(Date);
                    String Time = tokens[4] + " " + tokens[5];
                    wmap[i].setWtime(Time);
                    String Zone = tokens[6];
                    wmap[i].setZone(Zone);
                    String DDT = Date + " " + Time;
                    wmap[i].setDdt(DDT);
                    //System.out.println("Forecast : ");
                    wmap[i].setForecast_day(feed.valueOf("/rss/channel/item/yweather:forecast/@day"));
                    wmap[i].setForecast_date(feed.valueOf("/rss/channel/item/yweather:forecast/@date"));
                    wmap[i].setForecast_low(Float.parseFloat(feed.valueOf("/rss/channel/item/yweather:forecast/@low")));
                    wmap[i].setForecast_high(Float.parseFloat(feed.valueOf("/rss/channel/item/yweather:forecast/@high")));
                    wmap[i].setForecast_text(feed.valueOf("/rss/channel/item/yweather:forecast/@text"));
                    wmap[i].setForecast_code(Float.parseFloat(feed.valueOf("/rss/channel/item/yweather:forecast/@code")));
                    //System.out.println(zipcode);
                    }i++;

     }
        //WeatherInfo [] wmap = ClientData(routeZip,arrLat,arrLng,date);

        return wmap;
    }


    /*public WeatherInfo [] ClientData(ArrayList<String> c_zip,ArrayList<String> arrLat,ArrayList<String> arrLng,String date) {
       // ArrayList<WeatherInfo> cwInfo = new ArrayList<WeatherInfo>();
        System.out.println("I came here dude :");
       WeatherInfo [] cwInfo = new WeatherInfo[c_zip.size()];
        IDbConnect dbcon = new DbConnection();
        System.out.println("Inside cientdata");
        Connection con = dbcon.getConnection();
        int czval = 0;
        try {
            Statement stmt = con.createStatement();
            for (String czip : c_zip) {
                System.out.println("zipcode ..." + czip);
               // cwInfo.add(new WeatherInfo());
                String retinfo = "SELECT * FROM WEATHERTABLE WHERE ZIPCODE = '" + czip + "'AND FORECAST_DATE = '" + date + "'";

                //String ret = String.format(retinfo,czip);
                ResultSet rs = stmt.executeQuery(retinfo);
                while (rs.next()) {
                    cwInfo[czval].setLatitude(arrLat.get(czval));
                    cwInfo[czval].setLongitude(arrLng.get(czval));
                    cwInfo[czval].setZipcode(rs.getString("ZIPCODE"));
                    cwInfo[czval].setLoc_city(rs.getString("LOC_CITY"));
                    cwInfo[czval].setLoc_region(rs.getString("LOC_REGION"));
                    cwInfo[czval].setLoc_country(rs.getString("LOC_COUNTRY"));

                    cwInfo[czval].setUnits_temperature(rs.getString("UNITS_TEMP"));
                    cwInfo[czval].setUnits_distance(rs.getString("UNITS_DIST"));
                    cwInfo[czval].setUnits_pressure(rs.getString("UNITS_PRESSURE"));
                    cwInfo[czval].setUnits_speed(rs.getString("UNITS_SPEED"));

                    cwInfo[czval].setWind_chill(rs.getFloat("WIND_CHILL"));
                    cwInfo[czval].setWind_speed(rs.getFloat("WIND_SPEED"));
                    cwInfo[czval].setWind_direction(rs.getFloat("WIND_DIR"));

                    cwInfo[czval].setAtm_humidity(rs.getFloat("ATM_HUMIDITY"));
                    cwInfo[czval].setAtm_visibility(rs.getFloat("ATM_VISIBILITY"));
                    cwInfo[czval].setAtm_pressure(rs.getFloat("ATM_PRESSURE"));
                    cwInfo[czval].setAtm_rising(rs.getFloat("ATM_RISING"));


                    cwInfo[czval].setAstro_sunrise((rs.getTime("ATM_SUNRISE")).toString());
                    cwInfo[czval].setAstro_sunset((rs.getTime("ATM_SUNSET")).toString());

                    cwInfo[czval].setCond_code(rs.getFloat("COND_CODE"));
                    cwInfo[czval].setCond_text(rs.getString("COND_TEXT"));
                    cwInfo[czval].setCond_temp(rs.getFloat("COND_TEMP"));
                    cwInfo[czval].setCond_date(rs.getString("COND_DATE"));

                    cwInfo[czval].setDdt(rs.getString("DDT"));
                    cwInfo[czval].setDdt(rs.getString("DAY"));
                    cwInfo[czval].setDdt(rs.getTime("WTIME").toString());
                    cwInfo[czval].setDdt(rs.getString("ZONE"));


                    cwInfo[czval].setForecast_day(rs.getString("FORECAST_DAY"));
                    cwInfo[czval].setForecast_date((rs.getDate("FORECAST_DATE")).toString());
                    cwInfo[czval].setForecast_low(rs.getFloat("FORECAST_LOW"));
                    cwInfo[czval].setForecast_high(rs.getFloat("FORECAST_HIGH"));
                    cwInfo[czval].setForecast_text(rs.getString("FORECAST_TEXT"));
                    cwInfo[czval].setForecast_code(rs.getFloat("FORECAST_CODE"));
               }
                czval++;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
        return cwInfo;
    }*/

}
