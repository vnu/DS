/**
 * @author Vinu Charanya
 *
 */
package client;




//import java.io.Serializable;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import compute.IWeather;
import compute.WeatherInfo;
import java.util.ArrayList;




//import compute.IWeatherInfo;
public class WeatherClient {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (System.getSecurityManager() == null) {
			System.setSecurityManager(new SecurityManager());
		}
		try {
			String name = "IWeather";
			Registry registry = LocateRegistry.getRegistry(args[0]);
			IWeather client = (IWeather) registry.lookup(name);
			DispWeather disp = new DispWeather();
                        ArrayList<String> zipcodes = disp.GetZipcodes();
			System.out.println("Requesting the server to retrieve data\n");
			ArrayList<WeatherInfo> cwInfo = client.RetrieveData(zipcodes);
                        disp.weatherdisplay(cwInfo);
			
		} catch (Exception ex) {
			System.err.println("WeatherClient exception:");
			System.out.println(ex.getMessage());
                        ex.printStackTrace();
		}
		

	}

	
	
	

}
