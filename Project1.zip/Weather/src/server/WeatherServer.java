/**
 * @author Vinu Charanya
 *
 */
package server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import compute.IWeather;
import compute.WeatherInfo;
import dbConnection.DbConnection;
import dbConnection.IDbConnect;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

public class WeatherServer implements IWeather {

    static String[] zip;
    static ArrayList<String> zipcode = new ArrayList<String>();
    static ArrayList<WeatherInfo> wInfo;
    int i = 0, j = 0;
    WeatherInfo wInfos;

    public WeatherServer() {
        super();
    }

    @Override
    public ArrayList<WeatherInfo> RetrieveData(ArrayList<String> c_zip) throws RemoteException {
        ArrayList<WeatherInfo> c_wInfo = ClientData(c_zip);
        return c_wInfo;
    }

    public ArrayList<WeatherInfo> ClientData(ArrayList<String> c_zip) {
        ArrayList<WeatherInfo> cwInfo = new ArrayList<WeatherInfo>();
        IDbConnect dbcon = new DbConnection();
        System.out.println("Inside cientdata");
        Connection con = dbcon.getConnection();
        int czval = 0;
        try {
            Statement stmt = con.createStatement();
            for (String czip : c_zip) {
                System.out.println("zipcode ..."+czip);
                cwInfo.add(new WeatherInfo());
                String retinfo = "SELECT * FROM DBWEATHERTABLE WHERE ZIPCODE = '"+czip+"'";
                //String ret = String.format(retinfo,czip);
                ResultSet rs = stmt.executeQuery(retinfo);
                while (rs.next()) {
                    cwInfo.get(czval).setZipcode(rs.getString("ZIPCODE"));
                    cwInfo.get(czval).setLoc_city(rs.getString("LOC_CITY"));
                    cwInfo.get(czval).setLoc_region(rs.getString("LOC_REGION"));
                    cwInfo.get(czval).setLoc_country(rs.getString("LOC_COUNTRY"));

                    cwInfo.get(czval).setUnits_temperature(rs.getString("UNITS_TEMP"));
                    cwInfo.get(czval).setUnits_distance(rs.getString("UNITS_DIST"));
                    cwInfo.get(czval).setUnits_pressure(rs.getString("UNITS_PRESSURE"));
                    cwInfo.get(czval).setUnits_speed(rs.getString("UNITS_SPEED"));

                    cwInfo.get(czval).setWind_chill(rs.getInt("WIND_CHILL"));
                    cwInfo.get(czval).setWind_speed(rs.getInt("WIND_SPEED"));
                    cwInfo.get(czval).setWind_direction(rs.getInt("WIND_DIR"));

                    cwInfo.get(czval).setAtm_humidity(rs.getInt("ATM_HUMIDITY"));
                    cwInfo.get(czval).setAtm_visibility(rs.getFloat("ATM_VISIBILITY"));
                    cwInfo.get(czval).setAtm_pressure(rs.getFloat("ATM_PRESSURE"));
                    cwInfo.get(czval).setAtm_rising(rs.getInt("ATM_RISING"));

                    cwInfo.get(czval).setAstro_sunrise((rs.getTime("ATM_SUNRISE")).toString());
                    cwInfo.get(czval).setAstro_sunset((rs.getTime("ATM_SUNSET")).toString());

                    cwInfo.get(czval).setCond_code(rs.getInt("COND_CODE"));
                    cwInfo.get(czval).setCond_text(rs.getString("COND_TEXT"));
                    cwInfo.get(czval).setCond_temp(rs.getInt("COND_TEMP"));

                    cwInfo.get(czval).setForecast_day(rs.getString("FORECAST_DAY"));
                    cwInfo.get(czval).setForecast_date((rs.getDate("FORECAST_DATE")).toString());
                    cwInfo.get(czval).setForecast_low(rs.getInt("FORECAST_LOW"));
                    cwInfo.get(czval).setForecast_high(rs.getInt("FORECAST_HIGH"));
                    cwInfo.get(czval).setForecast_text(rs.getString("FORECAST_TEXT"));
                    cwInfo.get(czval).setForecast_code(rs.getInt("FORECAST_CODE"));


                }
                czval++;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
        return cwInfo;
    }

    public static ArrayList<String> readzip() throws FileNotFoundException, IOException {
        File file = new File("D:\\vinc\\Java\\Weather\\src\\lib\\zip.txt");
        BufferedReader reader = new BufferedReader(new FileReader(file));
        while (true) {
            String line;
            line = reader.readLine();
            if (line == null) {
                break;
            }
            zip = line.split(",");
            zipcode.add(zip[1]);
        }
        reader.close();
        System.out.println("I just finished reading files");
        return zipcode;
    }

    public static ArrayList<WeatherInfo> Retrievefeed(ArrayList<String> zipcode) {
        wInfo = new ArrayList<WeatherInfo>();
        int zval = 0;
        for (String zipc : zipcode) {
            wInfo.add(new WeatherInfo());
            System.out.println(zipc);
            String addr = "http://weather.yahooapis.com/forecastrss?p=" + zipc;
            URL myURL = null;
            try {
                myURL = new URL(addr);
            } catch (MalformedURLException ex) {
                System.out.println(ex.getMessage());
            }
            SAXReader xmlReader = new SAXReader();
            Document feed = null;
            try {
                feed = (Document) xmlReader.read(myURL);
            } catch (DocumentException ex) {
                System.out.println(ex.getMessage());
            }

            wInfo.get(zval).setTitle(feed.valueOf("/rss/channel/title/."));
            if (wInfo.get(zval).getTitle().equals("Yahoo! Weather - Error")) {
                System.out.println("Weather not found for the zip code : " + zipc);

            } else {
                wInfo.get(zval).setZipcode(zipc);
                //System.out.println("Location : ");
                wInfo.get(zval).setLoc_city(feed.valueOf("/rss/channel/yweather:location/@city"));
                wInfo.get(zval).setLoc_city(wInfo.get(zval).getLoc_city().replaceAll("'", " "));
                wInfo.get(zval).setLoc_region(feed.valueOf("/rss/channel/yweather:location/@region"));
                wInfo.get(zval).setLoc_country(feed.valueOf("/rss/channel/yweather:location/@country"));

                //System.out.println("Units : ");
                wInfo.get(zval).setUnits_temperature(feed.valueOf("/rss/channel/yweather:units/@temperature"));
                wInfo.get(zval).setUnits_distance(feed.valueOf("/rss/channel/yweather:units/@distance"));
                wInfo.get(zval).setUnits_pressure(feed.valueOf("/rss/channel/yweather:units/@pressure"));
                wInfo.get(zval).setUnits_speed(feed.valueOf("/rss/channel/yweather:units/@speed"));

                //System.out.println("Wind : ");
                String win_chill = feed.valueOf("/rss/channel/yweather:wind/@chill");
                if (win_chill != "") {
                    wInfo.get(zval).setWind_chill((Integer.parseInt(win_chill)));
                } else {
                    wInfo.get(zval).setWind_chill(0);
                }
                String win_dir = feed.valueOf("/rss/channel/yweather:wind/@direction");
                if (win_dir != "") {
                    wInfo.get(zval).setWind_direction(Integer.parseInt(win_dir));
                } else {
                    wInfo.get(zval).setWind_direction(0);
                }
                String win_speed = feed.valueOf("/rss/channel/yweather:wind/@speed");
                if (win_speed != "") {
                    wInfo.get(zval).setWind_speed(Integer.parseInt(win_speed));
                } else {
                    wInfo.get(zval).setWind_speed(0);
                }
                //System.out.println("Atmosphere : ");
                String atm_hum = feed.valueOf("/rss/channel/yweather:atmosphere/@humidity");
                if (atm_hum != "") {
                    wInfo.get(zval).setAtm_humidity(Integer.parseInt((atm_hum)));
                } else {
                    wInfo.get(zval).setAtm_humidity(0);
                }
                String atm_vis = feed.valueOf("/rss/channel/yweather:atmosphere/@visibility");
                if (atm_vis != "") {
                    wInfo.get(zval).setAtm_visibility(Float.parseFloat(atm_vis));
                } else {
                    wInfo.get(zval).setAtm_visibility(0);
                }

                String atm_pr = feed.valueOf("/rss/channel/yweather:atmosphere/@pressure");
                if (atm_pr != "") {
                    wInfo.get(zval).setAtm_pressure(Float.parseFloat(atm_pr));
                } else {
                    wInfo.get(zval).setAtm_pressure(0);
                }
                String atm_ris = feed.valueOf("/rss/channel/yweather:atmosphere/@rising");
                if (atm_ris != "") {
                    wInfo.get(zval).setAtm_rising(Integer.parseInt(atm_ris));
                } else {
                    wInfo.get(zval).setAtm_rising(0);
                }

                //System.out.println("Astronomy : ");
                wInfo.get(zval).setAstro_sunrise(feed.valueOf("/rss/channel/yweather:astronomy/@sunrise"));
                wInfo.get(zval).setAstro_sunset(feed.valueOf("/rss/channel/yweather:astronomy/@sunset"));

                //System.out.println("Condition : ");
                wInfo.get(zval).setCond_text(feed.valueOf("/rss/channel/item/yweather:condition/@text"));
                wInfo.get(zval).setCond_code(Integer.parseInt(feed.valueOf("/rss/channel/item/yweather:condition/@code")));
                wInfo.get(zval).setCond_temp(Integer.parseInt(feed.valueOf("/rss/channel/item/yweather:condition/@temp")));
                wInfo.get(zval).setCond_date(feed.valueOf("/rss/channel/item/yweather:condition/@date"));

                //System.out.println("Forecast : ");
                wInfo.get(zval).setForecast_day(feed.valueOf("/rss/channel/item/yweather:forecast/@day"));
                wInfo.get(zval).setForecast_date(feed.valueOf("/rss/channel/item/yweather:forecast/@date"));
                wInfo.get(zval).setForecast_low(Integer.parseInt(feed.valueOf("/rss/channel/item/yweather:forecast/@low")));
                wInfo.get(zval).setForecast_high(Integer.parseInt(feed.valueOf("/rss/channel/item/yweather:forecast/@high")));
                wInfo.get(zval).setForecast_text(feed.valueOf("/rss/channel/item/yweather:forecast/@text"));
                wInfo.get(zval).setForecast_code(Integer.parseInt(feed.valueOf("/rss/channel/item/yweather:forecast/@code")));
                //System.out.println(zipcode);
            }
            zval++;

        }
        return wInfo;

    }

    public static void StoreFeed(ArrayList<WeatherInfo> wInfoarr) {
        IDbConnect dbcon = new DbConnection();
        Connection con = dbcon.getConnection();
        try {
            Statement stmt = con.createStatement();
            try {
                String table = "CREATE TABLE DBWEATHERTABLE(ZIPCODE VARCHAR(30), LOC_CITY VARCHAR(30), LOC_REGION VARCHAR(30), LOC_COUNTRY VARCHAR(30),UNITS_TEMP VARCHAR(10), UNITS_DIST VARCHAR(10), UNITS_PRESSURE VARCHAR(10), UNITS_SPEED VARCHAR(10), WIND_CHILL INTEGER, WIND_DIR INTEGER, WIND_SPEED INTEGER, ATM_HUMIDITY INTEGER, ATM_VISIBILITY FLOAT, ATM_PRESSURE FLOAT, ATM_RISING INTEGER, ATM_SUNRISE TIME, ATM_SUNSET TIME, COND_TEXT VARCHAR(50), COND_CODE INTEGER, COND_TEMP INTEGER, FORECAST_DAY VARCHAR(10), FORECAST_DATE DATE, FORECAST_LOW INTEGER, FORECAST_HIGH INTEGER, FORECAST_TEXT VARCHAR(50), FORECAST_CODE INTEGER, PRIMARY KEY(ZIPCODE,FORECAST_DATE) )";
                stmt.executeUpdate(table);
                System.out.println("Table Created Successfully\n");
            } catch (SQLException e) {
                System.out.println("Table Already Exists.. Continuing with Inserting Data \n");
            }

            for (WeatherInfo wInfos : wInfoarr) {
                try {
                    String infovalue = "INSERT INTO DBWEATHERTABLE(ZIPCODE,LOC_CITY, LOC_REGION, LOC_COUNTRY,UNITS_TEMP, UNITS_DIST, UNITS_PRESSURE, UNITS_SPEED, WIND_CHILL, WIND_DIR, WIND_SPEED, ATM_HUMIDITY, ATM_VISIBILITY, ATM_PRESSURE, ATM_RISING, ATM_SUNRISE, ATM_SUNSET, COND_TEXT, COND_CODE, COND_TEMP, FORECAST_DAY, FORECAST_DATE, FORECAST_LOW, FORECAST_HIGH, FORECAST_TEXT, FORECAST_CODE)VALUES('" + wInfos.getZipcode() + "','" + wInfos.getLoc_city() + "','" + wInfos.getLoc_region() + "','" + wInfos.getLoc_country() + "','" + wInfos.getUnits_temperature() + "','" + wInfos.getUnits_distance() + "','" + wInfos.getUnits_pressure() + "','" + wInfos.getUnits_speed() + "','" + wInfos.getWind_chill() + "','" + wInfos.getWind_direction() + "','" + wInfos.getWind_speed() + "','" + wInfos.getAtm_humidity() + "','" + wInfos.getAtm_visibility() + "','" + wInfos.getAtm_pressure() + "','" + wInfos.getAtm_rising() + "',STR_TO_DATE('" + wInfos.getAstro_sunrise() + "','%l:%i %p'),STR_TO_DATE('" + wInfos.getAstro_sunset() + "','%l:%i %p'),'" + wInfos.getCond_text() + "','" + wInfos.getCond_code() + "','" + wInfos.getCond_temp() + "','" + wInfos.getForecast_day() + "',STR_TO_DATE('" + wInfos.getForecast_date() + "','%d %M %Y'),'" + wInfos.getForecast_low() + "','" + wInfos.getForecast_high() + "','" + wInfos.getForecast_text() + "','" + wInfos.getForecast_code() + "')";
                    String infovalue1 = "INSERT INTO DBWEATHERINFO(ZIPCODE,LOC_CITY, LOC_REGION, LOC_COUNTRY,UNITS_TEMP, UNITS_DIST, UNITS_PRESSURE, UNITS_SPEED, WIND_CHILL, WIND_DIR, WIND_SPEED, ATM_HUMIDITY, ATM_VISIBILITY, ATM_PRESSURE, ATM_RISING, ATM_SUNRISE, ATM_SUNSET, COND_TEXT, COND_CODE, COND_TEMP, FORECAST_DAY, FORECAST_DATE, FORECAST_LOW, FORECAST_HIGH, FORECAST_TEXT, FORECAST_CODE)VALUES('" + wInfos.getZipcode() + "','" + wInfos.getLoc_city() + "','" + wInfos.getLoc_region() + "','" + wInfos.getLoc_country() + "','" + wInfos.getUnits_temperature() + "','" + wInfos.getUnits_distance() + "','" + wInfos.getUnits_pressure() + "','" + wInfos.getUnits_speed() + "','" + wInfos.getWind_chill() + "','" + wInfos.getWind_direction() + "','" + wInfos.getWind_speed() + "','" + wInfos.getAtm_humidity() + "','" + wInfos.getAtm_visibility() + "','" + wInfos.getAtm_pressure() + "','" + wInfos.getAtm_rising() + "',STR_TO_DATE('" + wInfos.getAstro_sunrise() + "','%l:%i %p'),STR_TO_DATE('" + wInfos.getAstro_sunset() + "','%l:%i %p'),'" + wInfos.getCond_text() + "','" + wInfos.getCond_code() + "','" + wInfos.getCond_temp() + "','" + wInfos.getForecast_day() + "',STR_TO_DATE('" + wInfos.getForecast_date() + "','%d %M %Y'),'" + wInfos.getForecast_low() + "','" + wInfos.getForecast_high() + "','" + wInfos.getForecast_text() + "','" + wInfos.getForecast_code() + "')";
                    stmt.executeUpdate(infovalue);
                    stmt.executeUpdate(infovalue1);
                    System.out.println(wInfos.getZipcode());
                } catch (SQLException ex) {
                    System.out.println("Duplicate entry..");
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
    }

    public static void main(String[] args) {
        /* 
         * @The zipcodes are read from the text file and an ArrayList<String> of zipcodes
         * is returned.
         */
        try {
            readzip();
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        wInfo = Retrievefeed(zipcode);
        StoreFeed(wInfo);


        /*
         * The server connects to the registry and is ready
         * for service after this. It displays an output when it is ready.
         */
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }
        try {
            String name = "IWeather";
            IWeather server = new WeatherServer();
            IWeather stub = (IWeather) UnicastRemoteObject.exportObject(server, 0);
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind(name, stub);
            System.out.println("WeatherServer bound and ready for Service");
        } catch (Exception ex) {
            System.err.println("WeatherServer exception formed:");
            System.out.println(ex.getMessage());
        }
    }
}
