/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package web.server;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import weatherDB.WeatherInfo;

import dbConnection.DbConnection;
import dbConnection.IDbConnect;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Vnu
 */
@WebService()
public class weatherWeb {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "fConverter")
    public Float fahrenheitConverter(@WebParam(name = "fahrenheit")
    float fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "celciusConverter")
    public Float celsiusConverter(@WebParam(name = "celcius")
    float celsius) {
        return (celsius * 9 / 5) + 32;

    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "RetrieveData")
    public WeatherInfo RetrieveData(@WebParam(name = "czip")
    String czip) {
        WeatherInfo cwInfo = new WeatherInfo();
        IDbConnect dbcon = new DbConnection();
        System.out.println("Inside cientdata");
        Connection con = dbcon.getConnection();
        try {
            Statement stmt = con.createStatement();
            //for (String czip : c_zip) {
                System.out.println("zipcode ..."+czip);
                //cwInfo.add(new WeatherInfo());
                String retinfo = "SELECT * FROM DBWEATHERTABLE WHERE ZIPCODE = '"+czip+"'";
                //String ret = String.format(retinfo,czip);
                ResultSet rs = stmt.executeQuery(retinfo);
                while (rs.next()) {

                    cwInfo.setZipcode(rs.getString("ZIPCODE"));
                    cwInfo.setLoc_city(rs.getString("LOC_CITY"));
                    cwInfo.setLoc_region(rs.getString("LOC_REGION"));
                    cwInfo.setLoc_country(rs.getString("LOC_COUNTRY"));

                    cwInfo.setUnits_temperature(rs.getString("UNITS_TEMP"));
                    cwInfo.setUnits_distance(rs.getString("UNITS_DIST"));
                    cwInfo.setUnits_pressure(rs.getString("UNITS_PRESSURE"));
                    cwInfo.setUnits_speed(rs.getString("UNITS_SPEED"));

                    cwInfo.setWind_chill(rs.getInt("WIND_CHILL"));
                    cwInfo.setWind_speed(rs.getInt("WIND_SPEED"));
                    cwInfo.setWind_direction(rs.getInt("WIND_DIR"));

                    cwInfo.setAtm_humidity(rs.getInt("ATM_HUMIDITY"));
                    cwInfo.setAtm_visibility(rs.getFloat("ATM_VISIBILITY"));
                    cwInfo.setAtm_pressure(rs.getFloat("ATM_PRESSURE"));
                    cwInfo.setAtm_rising(rs.getInt("ATM_RISING"));

                    cwInfo.setAstro_sunrise((rs.getTime("ATM_SUNRISE")).toString());
                    cwInfo.setAstro_sunset((rs.getTime("ATM_SUNSET")).toString());
                    cwInfo.setCond_code(rs.getInt("COND_CODE"));
                    cwInfo.setCond_text(rs.getString("COND_TEXT"));
                    cwInfo.setCond_temp(rs.getInt("COND_TEMP"));

                    cwInfo.setForecast_day(rs.getString("FORECAST_DAY"));
                    cwInfo.setForecast_date((rs.getDate("FORECAST_DATE")).toString());
                    cwInfo.setForecast_low(rs.getInt("FORECAST_LOW"));
                    cwInfo.setForecast_high(rs.getInt("FORECAST_HIGH"));
                    cwInfo.setForecast_text(rs.getString("FORECAST_TEXT"));
                    cwInfo.setForecast_code(rs.getInt("FORECAST_CODE"));


                }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
        return cwInfo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "cityweather")
    public WeatherInfo cityweather(@WebParam(name = "city")
    String city, @WebParam(name = "date")
    String date) {
        WeatherInfo cwInfo = new WeatherInfo();
        IDbConnect dbcon = new DbConnection();
        System.out.println("Inside cientdata");
        Connection con = dbcon.getConnection();
        try {
            Statement stmt = con.createStatement();
            
                String retinfo = "SELECT * FROM DBWEATHERTABLE WHERE LOC_CITY = '"+city+"' AND FORECAST_DATE = '"+date+"'";
                System.out.println("date = "+date);
                System.out.println("cate = "+city);
                ResultSet rs = stmt.executeQuery(retinfo);
                while (rs.next()) {

                    cwInfo.setZipcode(rs.getString("ZIPCODE"));
                    cwInfo.setLoc_city(rs.getString("LOC_CITY"));
                    cwInfo.setLoc_region(rs.getString("LOC_REGION"));
                    cwInfo.setLoc_country(rs.getString("LOC_COUNTRY"));

                    cwInfo.setUnits_temperature(rs.getString("UNITS_TEMP"));
                    cwInfo.setUnits_distance(rs.getString("UNITS_DIST"));
                    cwInfo.setUnits_pressure(rs.getString("UNITS_PRESSURE"));
                    cwInfo.setUnits_speed(rs.getString("UNITS_SPEED"));

                    cwInfo.setWind_chill(rs.getInt("WIND_CHILL"));
                    cwInfo.setWind_speed(rs.getInt("WIND_SPEED"));
                    cwInfo.setWind_direction(rs.getInt("WIND_DIR"));

                    cwInfo.setAtm_humidity(rs.getInt("ATM_HUMIDITY"));
                    cwInfo.setAtm_visibility(rs.getFloat("ATM_VISIBILITY"));
                    cwInfo.setAtm_pressure(rs.getFloat("ATM_PRESSURE"));
                    cwInfo.setAtm_rising(rs.getInt("ATM_RISING"));

                    cwInfo.setAstro_sunrise((rs.getTime("ATM_SUNRISE")).toString());
                    cwInfo.setAstro_sunset((rs.getTime("ATM_SUNSET")).toString());
                    cwInfo.setCond_code(rs.getInt("COND_CODE"));
                    cwInfo.setCond_text(rs.getString("COND_TEXT"));
                    cwInfo.setCond_temp(rs.getInt("COND_TEMP"));

                    cwInfo.setForecast_day(rs.getString("FORECAST_DAY"));
                    cwInfo.setForecast_date((rs.getDate("FORECAST_DATE")).toString());
                    cwInfo.setForecast_low(rs.getInt("FORECAST_LOW"));
                    cwInfo.setForecast_high(rs.getInt("FORECAST_HIGH"));
                    cwInfo.setForecast_text(rs.getString("FORECAST_TEXT"));
                    cwInfo.setForecast_code(rs.getInt("FORECAST_CODE"));


                }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
        return cwInfo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CityAverage")
    public int CityAverage(@WebParam(name = "City")
    String City, @WebParam(name = "FirstDate")
    String FirstDate, @WebParam(name = "SecondDate")
    String SecondDate) {
        int avg=0;
          WeatherInfo cwInfo = new WeatherInfo();
        IDbConnect dbcon = new DbConnection();
        System.out.println("Inside cientdata");
        Connection con = dbcon.getConnection();
        
        try {
            Statement stmt = con.createStatement();

                String retinfo = "SELECT AVG(COND_TEMP) AS AVGTEMP FROM DBWEATHERTABLE WHERE LOC_CITY = '"+City+"' AND FORECAST_DATE BETWEEN '"+FirstDate+"' AND '"+SecondDate+"'";
                ResultSet rs = stmt.executeQuery(retinfo);
                avg=rs.getInt("AVGTEMP");


        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
        System.out.println("\nClosing the database Connection..");
        dbcon.close();
        System.out.println("average"+avg);
        return avg;
    }

    }



