/**
* @author Vinu Charanya
 *
 */
package weatherDB;

import java.io.Serializable;


/**
 * 
 * Class with variables to store data from RSS feed retrieved by WeatherServer.
 * 
 */
public class WeatherInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	String title;
	String zipcode;
	String loc_city;
	String loc_region;
	String loc_country;
	String units_temperature;
	String units_distance;
	String units_pressure;
	String units_speed;
	int wind_chill;
	int wind_direction;
	int wind_speed;
	int atm_humidity;
	float atm_visibility;
	float atm_pressure;
	int atm_rising;
	String astro_sunrise;
	String astro_sunset;
	String cond_text;
	int cond_code;
	int cond_temp;
	String cond_date;
	String forecast_day;
	String forecast_date;
	int forecast_low;
	int forecast_high;
	String forecast_text;
	int forecast_code;

    public String getAstro_sunrise() {
        return astro_sunrise;
    }

    public void setAstro_sunrise(String astro_sunrise) {
        this.astro_sunrise = astro_sunrise;
    }

    public String getAstro_sunset() {
        return astro_sunset;
    }

    public void setAstro_sunset(String astro_sunset) {
        this.astro_sunset = astro_sunset;
    }

    public int getAtm_humidity() {
        return atm_humidity;
    }

    public void setAtm_humidity(int atm_humidity) {
        this.atm_humidity = atm_humidity;
    }

    public float getAtm_pressure() {
        return atm_pressure;
    }

    public void setAtm_pressure(float atm_pressure) {
        this.atm_pressure = atm_pressure;
    }

    public int getAtm_rising() {
        return atm_rising;
    }

    public void setAtm_rising(int atm_rising) {
        this.atm_rising = atm_rising;
    }

    public float getAtm_visibility() {
        return atm_visibility;
    }

    public void setAtm_visibility(float atm_visibility) {
        this.atm_visibility = atm_visibility;
    }

    public int getCond_code() {
        return cond_code;
    }

    public void setCond_code(int cond_code) {
        this.cond_code = cond_code;
    }

    public String getCond_date() {
        return cond_date;
    }

    public void setCond_date(String cond_date) {
        this.cond_date = cond_date;
    }

    public int getCond_temp() {
        return cond_temp;
    }

    public void setCond_temp(int cond_temp) {
        this.cond_temp = cond_temp;
    }

    public String getCond_text() {
        return cond_text;
    }

    public void setCond_text(String cond_text) {
        this.cond_text = cond_text;
    }

    public int getForecast_code() {
        return forecast_code;
    }

    public void setForecast_code(int forecast_code) {
        this.forecast_code = forecast_code;
    }

    public String getForecast_date() {
        return forecast_date;
    }

    public void setForecast_date(String forecast_date) {
        this.forecast_date = forecast_date;
    }

    public String getForecast_day() {
        return forecast_day;
    }

    public void setForecast_day(String forecast_day) {
        this.forecast_day = forecast_day;
    }

    public int getForecast_high() {
        return forecast_high;
    }

    public void setForecast_high(int forecast_high) {
        this.forecast_high = forecast_high;
    }

    public int getForecast_low() {
        return forecast_low;
    }

    public void setForecast_low(int forecast_low) {
        this.forecast_low = forecast_low;
    }

    public String getForecast_text() {
        return forecast_text;
    }

    public void setForecast_text(String forecast_text) {
        this.forecast_text = forecast_text;
    }

    public String getLoc_city() {
        return loc_city;
    }

    public void setLoc_city(String loc_city) {
        this.loc_city = loc_city;
    }

    public String getLoc_country() {
        return loc_country;
    }

    public void setLoc_country(String loc_country) {
        this.loc_country = loc_country;
    }

    public String getLoc_region() {
        return loc_region;
    }

    public void setLoc_region(String loc_region) {
        this.loc_region = loc_region;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUnits_distance() {
        return units_distance;
    }

    public void setUnits_distance(String units_distance) {
        this.units_distance = units_distance;
    }

    public String getUnits_pressure() {
        return units_pressure;
    }

    public void setUnits_pressure(String units_pressure) {
        this.units_pressure = units_pressure;
    }

    public String getUnits_speed() {
        return units_speed;
    }

    public void setUnits_speed(String units_speed) {
        this.units_speed = units_speed;
    }

    public String getUnits_temperature() {
        return units_temperature;
    }

    public void setUnits_temperature(String units_temperature) {
        this.units_temperature = units_temperature;
    }

    public int getWind_chill() {
        return wind_chill;
    }

    public void setWind_chill(int wind_chill) {
        this.wind_chill = wind_chill;
    }

    public int getWind_direction() {
        return wind_direction;
    }

    public void setWind_direction(int wind_direction) {
        this.wind_direction = wind_direction;
    }

    public int getWind_speed() {
        return wind_speed;
    }

    public void setWind_speed(int wind_speed) {
        this.wind_speed = wind_speed;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
	
}
