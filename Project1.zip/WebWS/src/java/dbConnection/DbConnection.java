/**
 * 
 */
package dbConnection;



//import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;





/**
 * @author Vnu
 *
 */
public class DbConnection implements IDbConnect{

	
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	
	Connection con = null;
	public DbConnection()
	{
		System.out.println("===Connecting to database ===\n");
		init();
        	
	}
	
	 public void init()
	    {
	        try
	        {
	            System.out.println("....Initializing database Connection....\n");
	        }
	        catch(Exception exception)
	        {
	            System.out.println("In Initialization.." + exception);
	        }
	    }
	

	@Override
	public Connection getConnection() {
		 try {
		      Class.forName("com.mysql.jdbc.Driver").newInstance();
		      con = DriverManager.getConnection("jdbc:mysql:///dbweather","root", "angel");

		      if(!con.isClosed());
		      System.out.println("**** Successfully connected to dbweather MySQL Database ****\n");

		    } catch(Exception e) {
		      System.err.println("Get Connection Exception: " + e.getMessage());
                      e.printStackTrace();
		    }
		return con;
	}

	@Override
	public void close() {
		try
        {
			if(con!=null)
            con.close();
            System.out.println("****Database is successfully Disconnected****\n");
        }
        catch(Exception ex	)
        {
            System.out.println("DB Close Exception : " + ex);
        }
		
	}

	

}
